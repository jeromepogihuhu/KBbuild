package com.example.kbdisplace;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import java.util.List;

/**
 * KB Displacement — one-key auto flick + attack.
 *
 * Press key → yaw snaps → sprint forced → attack fires with that look dir
 * → camera + sprint restored. Full auto on keybind.
 *
 * V = side (+90°)
 * B = back (+180°)
 * N = pull (face nearest target)
 */
public class KbDisplace implements ClientModInitializer {

	private static KeyBinding sideDisplace;
	private static KeyBinding backDisplace;
	private static KeyBinding pullDisplace;

	private static boolean pending;
	private static float pendingYaw;
	private static float pendingPitch = Float.NaN;
	private static float restoreYaw;
	private static float restorePitch;
	private static float restoreHeadYaw;
	private static boolean forceSprintRestore;

	@Override
	public void onInitializeClient() {
		sideDisplace = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.kbdisplace.side",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_V,
				"key.category.kbdisplace"
		));
		backDisplace = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.kbdisplace.up",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_B,
				"key.category.kbdisplace"
		));
		pullDisplace = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.kbdisplace.pull",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_N,
				"key.category.kbdisplace"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null || client.world == null) return;

			if (pending) {
				finishFlick(client);
				return;
			}

			while (sideDisplace.wasPressed()) {
				startFlick(client, client.player.getYaw() + 90.0f, Float.NaN);
			}
			while (backDisplace.wasPressed()) {
				startFlick(client, client.player.getYaw() + 180.0f, Float.NaN);
			}
			while (pullDisplace.wasPressed()) {
				Entity t = findTarget(client, client.player, 3.5);
				if (t == null) continue;
				Vec3d eye = client.player.getEyePos();
				Vec3d center = t.getPos().add(0, t.getHeight() * 0.5, 0);
				Vec3d dir = center.subtract(eye).normalize();
				float yaw = (float) Math.toDegrees(Math.atan2(-dir.x, dir.z));
				float pitch = (float) Math.toDegrees(-Math.asin(Math.max(-1, Math.min(1, dir.y))));
				startFlick(client, yaw, pitch);
			}
		});
	}

	private void startFlick(MinecraftClient client, float yaw, float pitch) {
		ClientPlayerEntity p = client.player;
		if (p == null) return;

		restoreYaw = p.getYaw();
		restorePitch = p.getPitch();
		restoreHeadYaw = p.getHeadYaw();
		pendingYaw = yaw;
		pendingPitch = pitch;
		forceSprintRestore = !p.isSprinting();

		p.setSprinting(true);
		p.setYaw(pendingYaw);
		p.setHeadYaw(pendingYaw);
		p.prevYaw = pendingYaw;
		if (!Float.isNaN(pendingPitch)) {
			p.setPitch(pendingPitch);
			p.prevPitch = pendingPitch;
		}
		pending = true;
	}

	private void finishFlick(MinecraftClient client) {
		ClientPlayerEntity p = client.player;
		if (p == null) {
			pending = false;
			return;
		}

		attackTarget(client, p);

		p.setYaw(restoreYaw);
		p.setPitch(restorePitch);
		p.setHeadYaw(restoreHeadYaw);
		p.prevYaw = restoreYaw;
		p.prevPitch = restorePitch;
		if (forceSprintRestore) {
			p.setSprinting(false);
		}
		pending = false;
	}

	private void attackTarget(MinecraftClient client, ClientPlayerEntity player) {
		Entity target = null;
		HitResult hit = client.crosshairTarget;
		if (hit != null && hit.getType() == HitResult.Type.ENTITY) {
			Entity e = ((EntityHitResult) hit).getEntity();
			if (e instanceof LivingEntity && e != player && e.isAlive()) {
				target = e;
			}
		}
		if (target == null) {
			target = findTarget(client, player, 3.5);
		}
		if (target != null && client.interactionManager != null) {
			client.interactionManager.attackEntity(player, target);
			player.swingHand(Hand.MAIN_HAND);
		}
	}

	private Entity findTarget(MinecraftClient client, ClientPlayerEntity player, double range) {
		Vec3d eye = player.getEyePos();
		Box box = player.getBoundingBox().expand(range);
		List<Entity> entities = client.world.getOtherEntities(player, box, e ->
				e instanceof LivingEntity
						&& e.isAlive()
						&& e != player
						&& !(e instanceof PlayerEntity pe && pe.isSpectator())
		);
		return entities.stream()
				.filter(e -> eye.distanceTo(e.getPos().add(0, e.getHeight() * 0.5, 0)) <= range)
				.min(Comparator.comparingDouble(e ->
						eye.squaredDistanceTo(e.getPos().add(0, e.getHeight() * 0.5, 0))))
				.orElse(null);
	}
}
